import { getSupabaseClient } from '../../../supabase';

export class GroupRepository {
  async getAdminGroups(match?: Partial<any>): Promise<any[]> {
    const client = getSupabaseClient();
    if (!client) return [];
    let query = client.from("admin_groups").select("*").order("created_at", { ascending: false });
    if (match) query = query.match(match);
    const { data } = await query;
    return (data || []).map((g: any) => ({
      ...g,
      invite_fee: Number(g.invite_fee),
      admin_fee: Number(g.admin_fee)
    }));
  }

  async getAdminGroupById(id: string): Promise<any | undefined> {
    const groups = await this.getAdminGroups({ id });
    return groups[0];
  }

  async addAdminGroup(group: any): Promise<void> {
    const client = getSupabaseClient();
    if (!client) return;
    const { error } = await client.from("admin_groups").insert([{
      ...group,
      invite_fee: Number(group.invite_fee),
      admin_fee: Number(group.admin_fee)
    }]);
    if (error) throw error;
  }

  async updateAdminGroup(id: string, updates: Partial<any>): Promise<void> {
    const client = getSupabaseClient();
    if (!client) return;
    if (updates.invite_fee !== undefined) updates.invite_fee = Number(updates.invite_fee);
    if (updates.admin_fee !== undefined) updates.admin_fee = Number(updates.admin_fee);
    if (updates.max_participants !== undefined) updates.max_participants = Number(updates.max_participants);
    await client.from("admin_groups").update(updates).eq("id", id);
  }

  async deleteAdminGroup(id: string): Promise<void> {
    const client = getSupabaseClient();
    if (!client) return;
    await client.from("admin_groups").delete().eq("id", id);
  }

  async getActiveGroups(match?: Partial<any>): Promise<any[]> {
    const client = getSupabaseClient();
    if (!client) return [];
    let query = client.from("active_groups").select("*, admin_groups(name, description, invite_fee, is_public, rules, objective, rules_url, type, admin_fee, max_participants)").order("created_at", { ascending: false });
    if (match) query = query.match(match);
    const { data } = await query;
    return (data || []).map((g: any) => ({
      ...g,
      name: g.admin_groups?.name || "Grupo Desconhecido",
      description: g.admin_groups?.description || "",
      invite_fee: Number(g.admin_groups?.invite_fee) || 0,
      is_public: g.admin_groups?.is_public || false,
      rules: g.admin_groups?.rules || "",
      objective: g.admin_groups?.objective || "",
      rules_url: g.admin_groups?.rules_url || "",
      type: g.admin_groups?.type || "padrao",
      admin_fee: Number(g.admin_groups?.admin_fee) || 0,
      max_participants: Number(g.admin_groups?.max_participants) || 4,
    }));
  }

  async getActiveGroupById(id: string): Promise<any | undefined> {
    const groups = await this.getActiveGroups({ id });
    return groups[0];
  }

  async addActiveGroup(group: any): Promise<void> {
    const client = getSupabaseClient();
    if (!client) return;
    const { error } = await client.from("active_groups").insert([{
      id: group.id,
      admin_group_id: group.admin_group_id,
      status: group.status,
      created_at: group.created_at || new Date().toISOString()
    }]);
    if (error && error.code !== '23505') throw error;
  }

  async getGroupMembers(match?: Partial<any>): Promise<any[]> {
    const client = getSupabaseClient();
    if (!client) return [];
    let query = client.from("active_group_members").select("*");
    if (match) query = query.match(match);
    const { data } = await query;
    return (data || []).map((m: any) => ({
      ...m,
      position: Number(m.position)
    }));
  }

  async getMembersForGroup(groupId: string): Promise<any[]> {
    const members = await this.getGroupMembers({ active_group_id: groupId });
    return members.sort((a, b) => a.position - b.position);
  }

  async setGroupMembers(groupId: string, members: any[]): Promise<void> {
    const client = getSupabaseClient();
    if (!client) return;
    await client.from("active_group_members").delete().eq("active_group_id", groupId);
    if (members.length === 0) return;
    const inserts = members.map(m => ({
      ...m,
      position: Number(m.position),
      joined_at: m.joined_at || new Date().toISOString()
    }));
    await client.from("active_group_members").insert(inserts);
  }

  async getInvites(match?: Partial<any>): Promise<any[]> {
    const client = getSupabaseClient();
    if (!client) return [];
    let query = client.from("invites").select("*").order("created_at", { ascending: false });
    if (match) query = query.match(match);
    const { data } = await query;
    return data || [];
  }

  async getInviteByCode(code: string): Promise<any | undefined> {
    const invites = await this.getInvites({ invite_code: code });
    return invites[0];
  }

  async addInvite(invite: any): Promise<void> {
    const client = getSupabaseClient();
    if (!client) return;
    const { error } = await client.from("invites").insert([{
      ...invite,
      uses: Number(invite.uses),
      max_uses: Number(invite.max_uses)
    }]);
    if (error && error.code !== '23505') throw error;
  }

  async updateInvite(id: string, updates: Partial<any>): Promise<void> {
    const client = getSupabaseClient();
    if (!client) return;
    await client.from("invites").update(updates).eq("id", id);
  }

  async getUserInvitedGroups(match?: Partial<any>): Promise<any[]> {
    const client = getSupabaseClient();
    if (!client) return [];
    let query = client.from("user_invited_groups").select("*, admin_groups(name, description, invite_fee, is_public, rules, objective, rules_url, type, admin_fee, max_participants)").order("invited_at", { ascending: false });
    if (match) query = query.match(match);
    const { data } = await query;
    return (data || []).map((uig: any) => ({
      ...uig,
      name: uig.admin_groups?.name || "Grupo Desconhecido",
      description: uig.admin_groups?.description || "",
      invite_fee: Number(uig.admin_groups?.invite_fee) || 0,
      is_public: uig.admin_groups?.is_public || false,
      rules: uig.admin_groups?.rules || "",
      objective: uig.admin_groups?.objective || "",
      rules_url: uig.admin_groups?.rules_url || "",
      type: uig.admin_groups?.type || "padrao",
      admin_fee: Number(uig.admin_groups?.admin_fee) || 0,
      max_participants: Number(uig.admin_groups?.max_participants) || 4,
    }));
  }

  async addUserInvitedGroup(group: any): Promise<void> {
    const client = getSupabaseClient();
    if (!client) return;
    const { error } = await client.from("user_invited_groups").insert([{
      ...group,
      invited_at: group.invited_at || new Date().toISOString()
    }]);
    if (error && error.code !== '23505') throw error;
  }

  async deleteUserInvitedGroup(id: string): Promise<void> {
    const client = getSupabaseClient();
    if (!client) return;
    await client.from("user_invited_groups").delete().eq("id", id);
  }
}
